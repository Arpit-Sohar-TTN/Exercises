package com.im.test

import spock.lang.Specification

class EmailServiceSpec extends Specification {

}
