package com.im.test

class PersonSpec extends spock.lang.Specification {
    void "First test"(){
        expect:
        true
    }
}
