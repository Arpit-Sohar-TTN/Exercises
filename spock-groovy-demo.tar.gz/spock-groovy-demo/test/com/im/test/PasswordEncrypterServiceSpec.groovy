import com.im.test.PasswordEncrypterService
import spock.lang.Specification

/*
package com.im.test

import spock.lang.Specification

class PasswordEncrypterServiceSpec extends Specification {
    //todo
    def "Encrypted password is returned by the public method"() {

        given:
        PasswordEncrypterService passwordEncrypterService = Spy(PasswordEncrypterService)
        def password = "abcde12345"

        when:
        passwordEncrypterService.aVeryComplexProcess(password)>>  password.bytes.encodeBase64().toString()

        then:
        "dkk"
    }
}
*/
class PasswordEncrypterServiceSpec extends Specification {
    //todo
    def "Encrypted password is returned by the public method"() {
        given:
        PasswordEncrypterService encrypterService =Spy(PasswordEncrypterService)

        and :
        encrypterService.aVeryComplexProcess("password")>>{
            return "password".reverse()
        }

        when:
        String encrypt=encrypterService.encrypt("password")

        then:
        encrypt=="password".reverse()

    }
}