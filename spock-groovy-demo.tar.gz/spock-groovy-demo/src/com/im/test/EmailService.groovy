package com.im.test

class EmailService {
    void sendCancellationEmail(User user, String content){
               //sends cancellation email
    }
}
