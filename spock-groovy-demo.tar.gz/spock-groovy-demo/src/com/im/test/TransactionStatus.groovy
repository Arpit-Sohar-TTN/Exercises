package com.im.test

enum TransactionStatus {
    SUCCESSFUL,
    FAILED,
    IN_PROGRESS

}