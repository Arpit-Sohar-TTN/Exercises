package com.im.test

enum DiscountType {
    ALL,
    PRIVELLEGE_ONLY,
    NONE

}